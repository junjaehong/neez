package com.bbey.neez.DTO.company;

import lombok.Data;

@Data
public class RejectRequestDto {
    private String reason;
}
