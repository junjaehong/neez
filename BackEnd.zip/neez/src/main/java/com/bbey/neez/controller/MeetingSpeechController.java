package com.bbey.neez.controller;

import com.bbey.neez.security.SecurityUtil;
import com.bbey.neez.service.Meet.MeetingMinutesService;
import com.bbey.neez.service.Meet.MeetingSpeechStreamService;
import com.bbey.neez.service.Meet.MeetingSummaryService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/meetings/me")
@Tag(name = "Meeting Speech / STT API", description = "회의 음성 업로드 · STT · 요약 · 회의록 API\n\n" +
    "📌 meetingId란?\n" +
    "- 하나의 '회의 세션'을 구분하기 위한 ID입니다.\n" +
    "- Swagger에서는 임의의 숫자를 넣어 사용하면 됩니다. (예: 1)\n" +
    "- 같은 회의 동안에는 항상 같은 meetingId를 사용하세요.\n")
@SecurityRequirement(name = "BearerAuth")
public class MeetingSpeechController {

  private final MeetingSummaryService summaryService;
  private final MeetingMinutesService minutesService;
  private final MeetingSpeechStreamService streamService;

  public MeetingSpeechController(MeetingSummaryService summaryService,
      MeetingMinutesService minutesService,
      MeetingSpeechStreamService streamService) {
    this.summaryService = summaryService;
    this.minutesService = minutesService;
    this.streamService = streamService;
  }

  @Operation(summary = "단일 회의 음성 업로드 + STT + 요약", description = "하나의 전체 음성 파일을 업로드하여 STT와 요약을 수행합니다.\n"
      + "meetingId는 회의를 구분하는 임의의 숫자입니다. (예: 1)\n")
  @PostMapping(value = "/{meetingId}/audio", consumes = MediaType.MULTIPART_FORM_DATA_VALUE // 🔥 이 줄 추가
  )
  public ResponseEntity<Map<String, Object>> upload(
      @Parameter(description = "회의 세션 ID (예: 1)") @PathVariable Long meetingId,

      @Parameter(description = "업로드할 회의 음성 파일") @RequestPart("file") MultipartFile file, // 🔥 그대로 사용해도 됨

      @Parameter(description = "원본 언어 코드 (예: ko)", example = "ko") @RequestParam(value = "sourceLang", required = false) String sourceLang)
      throws Exception {

    Long userIdx = SecurityUtil.getCurrentUserIdx();

    try {
      MeetingSummaryService.MeetingSummary result = summaryService.summarize(userIdx, meetingId, file, sourceLang);

      Map<String, Object> payload = new LinkedHashMap<>();
      payload.put("userIdx", userIdx);
      payload.put("meetingId", meetingId);
      payload.put("filename", file.getOriginalFilename());
      payload.put("bytes", file.getSize());
      payload.put("text", result.transcript());
      payload.put("summary", result.summary());
      payload.put("speakers", result.speakerTurns());

      return ResponseEntity.ok(payload);

    } catch (IllegalArgumentException ex) {
      return badRequest(meetingId, ex.getMessage());
    } catch (IllegalStateException ex) {
      return serviceUnavailable(meetingId, ex.getMessage());
    } catch (RuntimeException ex) {
      return internalError(meetingId, ex.getMessage());
    }
  }

  @Operation(summary = "회의 음성 청크(STT Streaming) 업로드", description = "음성을 여러 조각(chunk)으로 나누어 업로드하면서 실시간 STT/번역을 수행합니다.\n"
      +
      "같은 회의 도중에는 항상 같은 meetingId를 사용합니다. (예: 1)\n")
  @PostMapping("/{meetingId}/chunks")
  public ResponseEntity<Map<String, Object>> uploadChunk(
      @Parameter(description = "회의 세션 ID", example = "1") @PathVariable Long meetingId,
      @RequestPart("file") MultipartFile file,
      @Parameter(description = "청크 순번", example = "1") @RequestParam(value = "index", required = false) Long index,
      @Parameter(description = "타겟 번역 언어", example = "ko") @RequestParam(value = "targetLang", required = false) String targetLang,
      @Parameter(description = "원본 음성 언어", example = "ko") @RequestParam(value = "sourceLang", required = false) String sourceLang)
      throws Exception {

    Long userIdx = SecurityUtil.getCurrentUserIdx();

    try {
      MeetingSpeechStreamService.Segment segment = streamService.processChunk(userIdx, meetingId, index, file,
          targetLang, sourceLang);

      Map<String, Object> payload = new LinkedHashMap<>();
      payload.put("userIdx", userIdx);
      payload.put("meetingId", meetingId);
      payload.put("index", segment.getIndex());
      payload.put("text", segment.getText());
      payload.put("receivedAt", segment.getReceivedAt());
      payload.put("bytes", segment.getBytes());
      payload.put("sourceLanguage", segment.getSourceLanguage());
      payload.put("targetLanguage", segment.getTargetLanguage());
      payload.put("translation", segment.getTranslatedText());
      payload.put("transcript", streamService.getTranscriptText(userIdx, meetingId));
      payload.put("segments", streamService.getSegments(userIdx, meetingId));

      return ResponseEntity.ok(payload);

    } catch (IllegalArgumentException ex) {
      return badRequest(meetingId, ex.getMessage());
    } catch (IllegalStateException ex) {
      return serviceUnavailable(meetingId, ex.getMessage());
    } catch (RuntimeException ex) {
      return internalError(meetingId, ex.getMessage());
    }
  }

  @Operation(summary = "현재까지의 transcript 조회", description = "누적된 transcript(원본 텍스트)와 segments 목록을 조회합니다.\n" +
      "meetingId는 동일 회의의 ID여야 합니다.\n")
  @GetMapping("/{meetingId}/transcript")
  public ResponseEntity<Map<String, Object>> getTranscript(
      @Parameter(description = "회의 세션 ID", example = "1") @PathVariable Long meetingId) {
    Long userIdx = SecurityUtil.getCurrentUserIdx();

    Map<String, Object> payload = new LinkedHashMap<>();
    payload.put("userIdx", userIdx);
    payload.put("meetingId", meetingId);
    payload.put("transcript", streamService.getTranscriptText(userIdx, meetingId));
    payload.put("segments", streamService.getSegments(userIdx, meetingId));

    return ResponseEntity.ok(payload);
  }

  @Operation(summary = "스트리밍 회의 최종 회의록 생성", description = "지금까지 업로드된 청크를 기준으로 전체 transcript / 한국어 번역본 / 요약 / segment 목록을 생성합니다.\n"
      + "선택적으로 bizCardId를 전달하면, 생성된 요약을 해당 명함의 메모에도 다음 형식으로 추가합니다.\n"
      + "[yyyy.MM.dd.HH:mm:ss]\n- 요약 1줄\n- 요약 2줄 ...")
  @PostMapping("/{meetingId}/minutes")
  public ResponseEntity<Map<String, Object>> finalizeStreamingMeeting(
      @Parameter(description = "회의 세션 ID", example = "1") @PathVariable Long meetingId,
      @Parameter(description = "요약을 연결할 명함 ID", example = "1") @RequestParam(value = "bizCardId", required = false) Long bizCardId) {
    Long userIdx = SecurityUtil.getCurrentUserIdx();

    try {
      MeetingMinutesService.StreamMeetingMinutes minutes = minutesService.finalizeStreamingMeeting(userIdx, meetingId,
          bizCardId);

      Map<String, Object> payload = new LinkedHashMap<>();
      payload.put("userIdx", userIdx);
      payload.put("meetingId", minutes.getMeetingId());
      payload.put("originalTranscript", minutes.getOriginalTranscript());
      payload.put("koreanTranscript", minutes.getKoreanTranscript());
      payload.put("summary", minutes.getSummary());
      payload.put("segments", minutes.getSegments());

      return ResponseEntity.ok(payload);

    } catch (IllegalArgumentException ex) {
      return badRequest(meetingId, ex.getMessage());
    } catch (IllegalStateException ex) {
      return serviceUnavailable(meetingId, ex.getMessage());
    } catch (RuntimeException ex) {
      return internalError(meetingId, ex.getMessage());
    }
  }

  /* ===== 공통 에러 처리 ===== */

  private ResponseEntity<Map<String, Object>> badRequest(Long meetingId, String msg) {
    Map<String, Object> error = new LinkedHashMap<>();
    error.put("meetingId", meetingId);
    error.put("error", "BAD_REQUEST");
    error.put("message", msg);
    return ResponseEntity.badRequest().body(error);
  }

  private ResponseEntity<Map<String, Object>> serviceUnavailable(Long meetingId, String msg) {
    Map<String, Object> error = new LinkedHashMap<>();
    error.put("meetingId", meetingId);
    error.put("error", "SERVICE_UNAVAILABLE");
    error.put("message", msg);
    return ResponseEntity.status(503).body(error);
  }

  private ResponseEntity<Map<String, Object>> internalError(Long meetingId, String msg) {
    Map<String, Object> error = new LinkedHashMap<>();
    error.put("meetingId", meetingId);
    error.put("error", "INTERNAL_ERROR");
    error.put("message", msg);
    return ResponseEntity.status(500).body(error);
  }
}
