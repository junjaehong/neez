package com.bbey.neez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeezApplicationTests {

	@Test
	void contextLoads() {
	}

}
